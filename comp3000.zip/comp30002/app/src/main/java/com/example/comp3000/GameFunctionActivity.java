package com.example.comp3000;

import android.app.DownloadManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.icu.text.AlphabeticIndex;
import android.util.Base64;
import android.view.textclassifier.TextLinks;
import android.widget.ImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class GameFunctionActivity {

    public static List<Record> records;
    public static int RandomLevelIDStorage;
    public static int TotalSigns;
    public static String UserButtonInput;
    public static String LevelAttributesStorage;

    //Access the API record using OkHttp
    public static void AccessAPI() {

        OkHttpClient client = new OkHttpClient();
        String url = "";
        String jsonData = null;

        //create new OkHttp request (Get a URL example on the Okhttp website)
        Request request = new Request.Builder()
                .url(url)
                .build();
        //If successful response, store Json array into String for conversion
        try {
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                jsonData = response.body().string();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        //convert jsonData String into a new list of Records
        records = new ArrayList<>();
        try {

            //create new Json array object with jsonData
            JSONArray jsonRecords = new JSONArray(jsonData);

            //for each record in the json array, copy object values for list
            for (int i = 0; i < jsonRecords.length(); i++) {
                JSONObject jsonRecord = jsonRecords.getJSONObject(i);
                int recordId = jsonRecord.getInt("recordID");

                //get the string of recordImage in jsonRecord then convert to byte[] array
                String recordImageText = jsonRecord.getString("recordImage");
                byte[] recordImage = Base64.decode(recordImageText, Base64.DEFAULT);

                String recordAttributes = jsonRecord.getString("recordAttributes");

                //add record to arraylist
                Record record = new Record(recordId, recordImage, recordAttributes);
                records.add(record);

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //Get a random record id number
    public static int GetRandomNumber() {
        Random rand = new Random();

        //produce Random number limit between records 12 - Max of the records list
        int upperbound = records.size();
        int int_random = rand.nextInt(upperbound - 12) + 12;
        RandomLevelIDStorage = int_random;
        return int_random;
    }
    //Reference previous random record id
    public static int CallRandomNumber() {
        return RandomLevelIDStorage;
    }

    //find record within the arraylist and convert byte array data to bitmap
    public static Bitmap GetImageBitmap(int id) {
        //A byteArray variable for ArrayList recordImage to be copied into
        byte[] imageData = new byte[0];

        //for each record in the arraylist
        for(Record record : records) {
            //if the recordID matches, copy the image byte array
            if(record.getRecordID() == id) {
                imageData = record.getRecordImage();
            }
        }

        //convert the byte array into a bitmap (BitmapFactory method in Android studio)
        Bitmap bitmap = BitmapFactory.decodeByteArray(imageData, 0, imageData.length);
        //return bitmap to imageview
        return bitmap;
    }
    //find record within the arraylist and return the attributes of the record
    public static String GetSignAmount(int int_random) {

        //String for Record Attributes to be copied into
        String levelAttributes = "";
        int numberofSigns = 0;
        String signamountText = "";

        //for each record in the arraylist
        for(Record record : records) {

            //if the recordID matches, copy the level attributes
            if(record.getRecordID() == int_random) {
                //store level attributes to variable
                levelAttributes = record.getRecordAttributes();
                LevelAttributesStorage = levelAttributes;
            }
        }
        //Find out Sign amount
        for(int i = 0; i < levelAttributes.length(); i++) {
            //if the char in levelAttributes is a 1
            if(levelAttributes.charAt(i) == '1') {
                //add to the sign amount counter
                numberofSigns ++;
            }
        }
        //set number of signs for score use later
        TotalSigns = numberofSigns;

        //set the sign amount into a message for the textview
        if(numberofSigns == 1) {
            signamountText = MessageFormat.format("Look at the Image for '{0}' sign of a phishing Scam", numberofSigns);
        }
        else
            signamountText = MessageFormat.format("Look at the Image for '{0}' signs of a phishing Scam", numberofSigns);
        return signamountText;
    }

    //Save users toggle button input
    public static void SaveButtonInput(String ToggleButtonValues) { UserButtonInput = ToggleButtonValues;}
    //compare user input to level record and return score result
    public static String ReturnScore() {
        String scoreamountText = "";
        int ScoreNumber = 0;

        //compare list of UserButtonInput and LevelAttributes
        for (int i = 0; i < UserButtonInput.length(); i++) {

            //check if Userbuttoninput is a 1 or a 0
            if (UserButtonInput.charAt(i) == '1' || UserButtonInput.charAt(i) == '0') {

                //check if User guess correctly according to the level attributes
                if (UserButtonInput.charAt(i) == LevelAttributesStorage.charAt(i)) {
                    ScoreNumber++;
                }
            }
        }

        //Return score amount in a message for the textview
        if(ScoreNumber == 1) {
            scoreamountText = MessageFormat.format("you detected: '{playerscore}' out of '{signamount}' sign", ScoreNumber, TotalSigns);
        }
        else
            scoreamountText = MessageFormat.format("you detected: '{playerscore}' out of '{signamount}' signs", ScoreNumber, TotalSigns);
        return scoreamountText;
    }

}


