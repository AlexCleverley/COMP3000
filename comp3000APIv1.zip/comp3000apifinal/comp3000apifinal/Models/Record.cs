﻿namespace comp3000apifinal.Models
{
    public class Record
    {
        public int recordID {  get; set; }
        public string recordImage { get; set; }
        public string recordAttributes { get; set; }
    }
}
