﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace comp3000.Models
{
    public class Record
    {
        private DataContext context;

        public int RecordID { get; set; }
        public byte[] RecordImage { get; set; }
        public string RecordAttributes { get; set; }
    }
}
