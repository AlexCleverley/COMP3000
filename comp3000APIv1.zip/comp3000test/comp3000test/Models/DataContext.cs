﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace comp3000.Models
{
    public class DataContext
    {
        public string ConnectionString { get; set; }

        public DataContext(string connectionString)
        {
            this.ConnectionString = connectionString;
        }

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(ConnectionString);
        }

        public List<Record> GetAllRecords()
        {
            List<Record> list = new List<Record>();

            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("select * from imagerecord", conn);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Record()
                        {
                            RecordID = Convert.ToInt32(reader["RecordID"]),
                            RecordImage = (byte[])reader["RecordImage"],
                            RecordAttributes = reader["RecordAttributes"].ToString()
                        });
                    }
                }
            }
            return list;
        }
    }
}
